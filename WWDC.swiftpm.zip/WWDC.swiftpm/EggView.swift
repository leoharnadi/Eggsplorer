//
//  EggView.swift
//  WWDC
//
//  Created by Leo Harnadi on 18/04/23.
//

import SwiftUI

struct EggView: View {
    @ObservedObject var egg: ButtonObject = eggObject
    
    var body: some View {
        Image("Egg")
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(height: frameHeight * 0.15)
            .offset(x: frameWidth * -0.05,
                    y: frameHeight * 0.18)
            .offset(x: egg.objectTarget.x,
                    y: egg.objectTarget.y)
            .background(
                    GeometryReader { geometry in
                        Color.clear
                            .onAppear {
                                egg.objectPosition = CGPoint(x: geometry.frame(in: .global).midX, y: geometry.frame(in: .global).midY)
                            }
                    }
            )
    }
}

