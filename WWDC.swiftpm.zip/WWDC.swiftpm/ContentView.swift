import SwiftUI

struct ContentView: View {
    @State var showIntro: Bool = true
    @State var showModal: Bool = false
    @State var showCredits: Bool = false
    
    @State var buttonOpacity: Double = 0
    
    @EnvironmentObject var selectionList: SelectionList
    
  
    var body: some View {
        GeometryReader { geometry in
           
            ZStack {
                Color("beige")
                    .ignoresSafeArea()
                Image("Kitchen")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width:frameWidth)
                    .ignoresSafeArea()
                
                VStack {
                    Spacer()
                        .frame(height: frameHeight * 0.05)
                    
                    
                    ZStack{
                        HStack(alignment: .center){
                            if selectionList.selection.count == 2 {
                                Text(selectionList.selection[0].imageName)
                                    .frame(maxWidth: textWidth)
                                Text("+")
                                    .frame(maxWidth: textWidth/3)
                                Text(selectionList.selection[1].imageName)
                                    .frame(maxWidth: textWidth)
                            } else if selectionList.selection.count == 1 {
                                Text(selectionList.selection[0].imageName)
                                    .frame(maxWidth: textWidth)
                                Text("+")
                                    .frame(maxWidth: textWidth/3)
                                Text("...")
                                    .frame(maxWidth: textWidth)
                            } else {
                                Text("...")
                                    .frame(maxWidth: textWidth)
                                Text("+")
                                    .frame(maxWidth: textWidth/3)
                                Text("...")
                                    .frame(maxWidth: textWidth)
                            }
                        }
                        .font(.custom("AvenirNext-Medium", size: 22))
                        .padding(5)
                        
                        
                    }
                    .frame(height: 50)
                    .background(Color("poppy"))
                    .foregroundColor(Color.white)
                    .cornerRadius(10)
                    .opacity(recipeFound ? 0 : 1)
                    .shadow(radius: 5)
                    
                    HStack(alignment: .bottom){
                        ForEach(objectArr) {
                            object in
                            ButtonView(buttonObject: object)
                                .scaleEffect(1.4)
                                .frame(width: frameWidth * 0.14)
                        }
                    }
                    .offset(y:frameHeight * 0.03)
                    
                    Spacer()
                    
                    ZStack{
//                        Color.red
                        
                        EggView()
                        
                        ResultView(resultObject: resultObject)
                            .onTapGesture {
                                if(recipeFound) {
                                    withAnimation(.easeIn(duration: 0.5)) {
                                        showModal = true
                                    }
                                    
                                    buttonOpacity = 0
                                
                                }
                            }
                            .onAppear() {
                                resultObject.objectTarget =                                 cauldronObject.objectPosition - resultObject.objectPosition
                            }
                        
                        
                    }
                    
                    
                    
                    Spacer()
                    
                    ZStack(){
                        CauldronView()
                        VStack(){
                            ZStack{
                                Button("Open Recipe") {
                                    withAnimation(.easeIn(duration: 0.5)) {
                                        showModal = true
                                        
                                    }
                                    
                                    audioPlayer.click()
                                    buttonOpacity = 0
                                }
                                .font(.custom("AvenirNext-Medium", size: 35))
                                .frame(width: frameWidth * 0.5, height: frameHeight * 0.05)
                                .padding()
                                .background(Color.yellow)
                                .cornerRadius(10)
                                .foregroundColor(Color.black)
                                .offset(y:frameHeight*0.15)
                                .opacity(buttonOpacity)
                                .shadow(radius: 10)
                                .onChange(of: recipeFound, perform: {_ in
                                    if recipeFound {
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
                                            withAnimation(.easeIn(duration: 1)) {
                                                self.buttonOpacity = 1
                                            }
                                        }
                                    }
                                    
                                    })
                                
                                Button(selectionList.hasSelectedTwo ? "Combine the Ingredients" : "Select Two Ingredients") {
                                    calculateCombination(object1: selectionList.selection[0], object2: selectionList.selection[1])
                                    
                                    audioPlayer.click()
                                }
                                .font(.custom("AvenirNext-Medium", size: 35))
                                .frame(width: frameWidth * 0.5, height: frameHeight * 0.05)
                                .padding()
                                .background(Color.yellow)
                                .cornerRadius(10)
                                .foregroundColor(Color.black)
                                .opacity(selectionList.hasSelectedTwo ? 1 : 0.5)
                                .offset(y:frameHeight*0.15)
                                .disabled(!selectionList.hasSelectedTwo)
                                .opacity(recipeFound ? 0 : 1)
                                .shadow(radius: 10)
                            }
                            
                            
                        }
                        
                    }
                    
                    
                    
                    
                    
                    
                    
                    
                }
                
                if showModal {
                    RecipeModalView(showModal: $showModal)
                        .zIndex(1)
                        .transition(.move(edge: .bottom))
                }
                
                if showIntro {
                    StartingModalView(showIntro: $showIntro, showCredits: $showCredits)
                        .zIndex(1)
                        .transition(.move(edge: .leading))
                }
                    
                if showCredits {
                    CreditsModalView(showCredits: $showCredits)
                        .zIndex(2)
                        .transition(.move(edge: .leading))
                }
                
                }
            .onAppear {
                audioPlayer.playBGM()
            }
        }
//          .frame(width: 1024, height: 1366)
//        .aspectRatio(3/4, contentMode: .fill)
        
        }
        
        
    }
