//
//  RecipeModalView.swift
//  WWDC
//
//  Created by Leo Harnadi on 15/04/23.
//

import SwiftUI

struct RecipeModalView: View {
    @Binding var showModal: Bool
    
    var body: some View {
        ZStack{
            Color("darkBeige").ignoresSafeArea()
            
            if let recipeImageName = recipeData.first(where: { $0.imageName == recipeImageName }) {
                VStack(){
                    
                    HStack() {
                        ZStack(){
                            Color.white
                                .frame(width: frameWidth * 0.4, height: frameWidth * 0.4)
                                .clipShape(Circle())
                            
                            Image(recipeImageName.imageName)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: frameWidth * 0.5)
                                .padding()
                                .shadow(radius: 10)
                        }
                        
                        Spacer()
                        
                        VStack() {
                            Text(recipeImageName.imageName)
                                .bold()
                                .scaleEffect(1.1)
                                .padding()
                                .multilineTextAlignment(.center)
                            Text(recipeImageName.chineseName)
                                .bold()
                                .padding()
                            Text(recipeImageName.chinesePronounciation)
                                .italic()
                                .padding()
                        }
                        .frame(width: frameWidth * 0.35)
                        .font(.custom("AvenirNext-Medium", size: 35))
                        .padding(.trailing, frameWidth * 0.1)
                        
                        Spacer()
                    }
                    .padding(.top, frameHeight * 0.04)
                    .padding(.bottom, frameHeight * 0.02)
                    
                    
                    VStack(){
                        
                        HStack(){
                            
                            VStack(alignment: .leading, spacing: 0){
                                Text("Ingredients")
                                    .bold()
                                    .scaleEffect(1.1)
                                Text(recipeImageName.ingredients)
                                    .padding(.top ,frameHeight * 0.005)
                                Spacer()
                            }
                            .frame(width: frameWidth * 0.2)
                            .padding(.leading, frameWidth * 0.02)
                            
                            Spacer()
                            
                            VStack(alignment: .leading, spacing: 0){
                                Text("Instructions")
                                    .bold()
                                    .scaleEffect(1.1)
                                Text(recipeImageName.instructions)
                                    .padding(.top ,frameHeight * 0.005)
                                Spacer()
                            }
                            .frame(width: frameWidth * 0.7)
                            .padding(.trailing, frameWidth * 0.02)
                        }
                        .frame(height: frameHeight * 0.2)
                        
                        
                        
                        VStack(alignment: .leading, spacing: 0){
                            HStack {
                                Text("Memories")
                                    .bold()
                                    .scaleEffect(1)
                                
                            }
                            HStack{
                                Text(recipeImageName.story)
                                    .padding(.top ,frameHeight * 0.003)
                            }
                            
                            
                        }
                        .padding([.trailing, .leading], frameWidth * 0.03)
                        
                        
                    }
                    .font(.custom("AvenirNext-Medium", size: 20))
                    
                    
                    Spacer()
                    
                    ZStack {
                        Button("Press To Try Again") {
                            withAnimation(.easeIn(duration: 0.5)) {
                                showModal.toggle()
                            }
                            
                            audioPlayer.click()
                            resetView()
                        }
                        .font(.custom("AvenirNext-Medium", size: 28))
                        .frame(width: frameWidth * 0.5, height: frameHeight * 0.05)
                        .padding()
                        .background(Color.yellow)
                        .cornerRadius(10)
                        .foregroundColor(Color.black)
                        .shadow(radius: 10)
                    }
                    .padding(.bottom, frameHeight * 0.01)
                }
                
                
                
            }
        }
        
        .foregroundColor(.black)
        
    }
}

