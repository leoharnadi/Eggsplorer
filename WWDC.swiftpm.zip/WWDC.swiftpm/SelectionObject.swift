//
//  SelectionObject.swift
//  WWDC
//
//  Created by Leo Harnadi on 11/04/23.
//

import Foundation
import SwiftUI

class SelectionList: ObservableObject {
    @Published var hasSelectedTwo: Bool
    @Published var selection: [ButtonObject]
    {
        didSet {
            withAnimation(.easeInOut(duration: 0.5)) {
                if selection.count == 2 {
                    hasSelectedTwo = true
                } else {
                    hasSelectedTwo = false
                }
            }
            
        }
    }

    func addItem(_ item: ButtonObject) {
        selection.append(item)
    }
    
    init() {
        selection = []
        hasSelectedTwo = false
    }
    
}
