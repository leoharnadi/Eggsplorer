//
//  ResultObject.swift
//  WWDC
//
//  Created by Leo Harnadi on 15/04/23.
//

import Foundation
import SwiftUI

class ResultObject: ObservableObject{
    @Published var imageName: String
    @Published var objectPosition: CGPoint
    @Published var objectTarget: CGPoint
    @Published var moveObject: Bool
    
    
    init() {
        self.imageName = "empty"
        self.objectPosition = .zero
        self.objectTarget = .zero
        self.moveObject = false
    }
}
