//
//  Starting Modal View.swift
//  WWDC
//
//  Created by Leo Harnadi on 15/04/23.
//

import SwiftUI

struct StartingModalView: View {
    @Binding var showIntro: Bool
    @Binding var showCredits: Bool
    
    var body: some View {
        ZStack {
            Color("darkBeige").ignoresSafeArea()
            VStack() {
                Text("Welcome to")
                    .bold()
                    .font(.custom("AvenirNext-Medium", size: 50))
                    .padding()
                    .foregroundColor(.black)
                    .shadow(radius: 10)
                    .offset(y: frameHeight * 0.01)
                
                
                Image("title")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .padding([.bottom, .trailing, .leading], frameWidth * 0.02)
                
                Text("Throughout my life, I have discovered numerous egg recipes passed down from different family members. These dishes holds a special place in my heart and has its own unique memories.\n\nIn this game, you can **eggsplore** the possibilities and discover new egg dishes just as I did, while also hopefully creating new lasting memories.")
                    .font(.custom("AvenirNext-Medium", size: 28))
                    .padding(25)
                
                Text("**How to Play:** Select two ingredients from the shelf and try to discover \(recipeData.count) different recipes!")
                    .italic()
                    .font(.custom("AvenirNext-Medium", size: 28))
                    .padding(25)
                    
                
                
                Spacer()
                
                Image("Egg")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .shadow(radius: 10)
                    .frame(height: frameHeight * 0.2)
                
                Spacer()
                
                
                
                ZStack {
                    Button {
                        withAnimation(.easeIn(duration: 0.5)) {
                            showIntro.toggle()
                        }
                        
                        audioPlayer.click()
                    } label: {
                        Text("Press To Start")
                            .bold()
                    }
                    .font(.custom("AvenirNext-Medium", size: 35))
                    .frame(width: frameWidth * 0.5, height: frameHeight * 0.05)
                    .padding()
                    .background(Color.yellow)
                    .cornerRadius(10)
                    .foregroundColor(Color.black)
                .shadow(radius: 10)
                    
                    HStack{
                        Spacer()
                        Button {
                            withAnimation(.easeIn(duration: 0.5)) {
                                showCredits.toggle()
                            }
                            
                            audioPlayer.click()
                        } label: {
                            Text("Credits")
                                .italic()
                        }
                        .font(.custom("AvenirNext-Medium", size: 12))
                        .frame(width: frameWidth * 0.05, height: frameHeight * 0.02)
                        .padding()
                        .background(Color.yellow)
                        .cornerRadius(10)
                        .foregroundColor(Color.black)
                        .shadow(radius: 5)
                        .offset(x: frameWidth * -0.06)
                    }
                }
                .padding(.bottom, frameHeight * 0.01)
            }
            
        }
        .foregroundColor(.black)
        
    }
}

