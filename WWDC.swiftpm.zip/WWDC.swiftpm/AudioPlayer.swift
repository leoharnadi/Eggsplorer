//
//  audioPlayer.swift
//  WWDC
//
//  Created by Leo Harnadi on 19/04/23.
//

import Foundation
import AVFoundation

class AudioPlayer {
    var BGMPlayer: AVAudioPlayer?
    var soundPlayer: AVAudioPlayer?
    var bubblesPlayer: AVAudioPlayer?

    func playBGM() {
        guard let url = Bundle.main.url(forResource: "backgroundMusic", withExtension: "mp3") else { return }

        do {
            BGMPlayer = try AVAudioPlayer(contentsOf: url)
            BGMPlayer?.numberOfLoops = -1
            BGMPlayer?.volume = 0.1
            BGMPlayer?.play()
        } catch {
            print("Error playing sound: \(error.localizedDescription)")
        }
    }
    
    func click() {
        guard let url = Bundle.main.url(forResource: "click", withExtension: "wav") else { return }

        do {
            soundPlayer = try AVAudioPlayer(contentsOf: url)
            soundPlayer?.volume = 2
            soundPlayer?.play()
        } catch {
            print("Error playing sound: \(error.localizedDescription)")
        }
    }
    
    func bubbles() {
        guard let url = Bundle.main.url(forResource: "bubbles", withExtension: "wav") else { return }

        do {
            bubblesPlayer = try AVAudioPlayer(contentsOf: url)
            bubblesPlayer?.volume = 2
            bubblesPlayer?.play()
        } catch {
            print("Error playing sound: \(error.localizedDescription)")
        }
    }
    
}
