//
//  Functions.swift
//  WWDC
//
//  Created by Leo Harnadi on 10/04/23.
//

import Foundation
import SwiftUI

func calculateCombination(object1: ButtonObject, object2: ButtonObject) {
    
    let cauldronDelay: Double = 4
    let selectedSet: Set<String> = [object1.imageName,object2.imageName]
    
    withAnimation(.easeInOut(duration: 0.4)) {
        object1.isSelected.toggle()
        object2.isSelected.toggle()
    }
    
    
    
    let recipeName = combos[selectedSet]
    
    if (recipeName != nil) {
        moveObjectToCauldron(object1: object1, object2: object2)
        
        recipeImageName = recipeName!
        
        recipeFound.toggle()
        
        shakeCauldron(duration: cauldronDelay)
        audioPlayer.bubbles()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + cauldronDelay) {

            withAnimation(.easeIn(duration: 1)) {
                resultObject.moveObject.toggle()
            }

        }
        
    } else {
        let timer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { _ in
            withAnimation(.easeInOut(duration: 0.1)) {
                    object1.shakeValue = object1.shakeValue == 5 ? -5 : 5
                    object2.shakeValue = object2.shakeValue == 5 ? -5 : 5
                            }
                        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            withAnimation(.easeInOut(duration: 0.1)) {
                    object1.shakeValue = 0
                    object2.shakeValue = 0
                }
                
                timer.invalidate()
            }
    }
    
    selectionList.selection.removeAll()
    
    
}

func moveObjectToCauldron(object1: ButtonObject, object2: ButtonObject) {
        
    
    
    withAnimation(.easeIn(duration: 1)) {
        object1.objectTarget = cauldronObject.objectPosition - object1.objectPosition
        object2.objectTarget = cauldronObject.objectPosition - object2.objectPosition
        eggObject.objectTarget = cauldronObject.objectPosition - eggObject.objectPosition

    }
    
}

func shakeCauldron(duration: Double) {
    
    let timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
        withAnimation(.easeInOut(duration: 1)) {
                cauldronObject.isShaking = cauldronObject.isShaking == 2.5 ? -2.5 : 2.5
                        }
                    }
    
        DispatchQueue.main.asyncAfter(deadline: .now() + duration) {
            withAnimation(.easeInOut(duration: 1)) {
                cauldronObject.isShaking = 0
            }
            
            timer.invalidate()
        }
}

func resetView() {
    recipeFound = false
    for object in objectArr {
        object.objectTarget = .zero
    }
    resultObject.moveObject = false
    eggObject.objectTarget = .zero
}
