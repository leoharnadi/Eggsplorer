//
//  CreditsModalView.swift
//  WWDC
//
//  Created by Leo Harnadi on 19/04/23.
//

import SwiftUI

struct CreditsModalView: View {
    @Binding var showCredits: Bool
    
    var body: some View {
        
        ZStack {
            Color("darkBeige").ignoresSafeArea()
            VStack{
                Text("Credits")
                    .bold()
                    .font(.custom("AvenirNext-Medium", size: 35))
                
                VStack(alignment: .leading) {
                    Text("Background Music:\nMelody of Nature by GoodBMusic \n https://soundcloud.com/goodbmusic-zakhar-valaha\nMusic promoted by\n https://www.chosic.com/free-music/all/\nCreative Commons CC BY 3.0\nhttps://creativecommons.org/licenses/by/3.0/\n\nSound Effect:\nClick Sound Effect by EminYILDIRIM \nhttps://freesound.org/people/EminYILDIRIM/sounds/536108/\nCreative Commons CC BY 4.0\nhttps://creativecommons.org/licenses/by/4.0/\n\nBubbles Sound Effect by ristooooo1\nhttps://freesound.org/people/ristooooo1/sounds/539823/\nCreative Commons CC BY 1.0\nhttps://creativecommons.org/publicdomain/zero/1.0/")
                        .font(.custom("AvenirNext-Medium", size: 20))
                        .padding()
                        .frame(width: frameWidth * 0.5)
                    Spacer()
                    
                    Button {
                        withAnimation(.easeIn(duration: 0.5)) {
                            showCredits.toggle()
                        }
                        
                        audioPlayer.click()
                    } label: {
                        Text("Go Back to Title")
                            .bold()
                    }
                    .font(.custom("AvenirNext-Medium", size: 35))
                    .frame(width: frameWidth * 0.5, height: frameHeight * 0.05)
                    .padding()
                    .background(Color.yellow)
                    .cornerRadius(10)
                    .foregroundColor(Color.black)
                    .shadow(radius: 10)
                }
                .padding()
            }
            .foregroundColor(.black)
        }
    }
    
    
}
