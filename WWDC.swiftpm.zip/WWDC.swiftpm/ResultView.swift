//
//  ResultView.swift
//  WWDC
//
//  Created by Leo Harnadi on 15/04/23.
//

import SwiftUI

struct ResultView: View {
    @ObservedObject var resultObject: ResultObject
    @State var glowActive: Bool = false
    @State var rotateActive: Bool = false
    
    var body: some View {
        
        ZStack{
            
            Image("Glow")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(maxHeight:frameHeight * 0.3)
                .scaleEffect(glowActive ? 1.2 : 1.3)
                .opacity(glowActive ? 0.5 : 0.8)
                .onAppear {
                    Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { _ in
                        withAnimation(.easeInOut(duration: 2)) {
                                            self.glowActive.toggle()
                                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                            withAnimation(.easeInOut(duration: 2)) {
                                                self.rotateActive.toggle()
                                            }
                        }
                                    }
                }
                .opacity(resultObject.moveObject ? 1 : 0)
            
            
            Image(recipeImageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(maxHeight: frameHeight * 0.1)
                .offset(x: resultObject.moveObject ? .zero : resultObject.objectTarget.x,
                        y: resultObject.moveObject ? .zero : resultObject.objectTarget.y)
                .opacity(resultObject.moveObject ? 1 : 0)
                .scaleEffect(rotateActive ? 1 : 1.1)
                .scaleEffect(resultObject.moveObject ? 3 : 1)
                .rotationEffect(rotateActive ? .degrees(-5) : .degrees(5))
                .background(
                    GeometryReader { geometry in
                        Color.clear
                            .onAppear {
                                resultObject.objectPosition = CGPoint(x: geometry.frame(in: .global).midX, y: geometry.frame(in: .global).midY)
                            }
                    }
            )
        }
        .offset(y:frameHeight * 0.1)
        
    }
}

