//
//  Globals.swift
//  WWDC
//
//  Created by Leo Harnadi on 11/04/23.
//

import Foundation
import SwiftUI

var frameWidth: CGFloat = UIScreen.main.bounds.size.width
var frameHeight: CGFloat = UIScreen.main.bounds.size.height

let waterObject = ButtonObject(imageName: "Water")
let teaObject = ButtonObject(imageName: "Tea")
let oilObject = ButtonObject(imageName: "Oil")
let riceObject = ButtonObject(imageName: "Rice")
let soySauceObject = ButtonObject(imageName: "Soy Sauce")
let onionObject = ButtonObject(imageName: "Onions")

let eggObject = ButtonObject(imageName: "Egg")
let cauldronObject = ButtonObject(imageName: "cauldron")


let resultObject = ResultObject()

let objectArr: [ButtonObject] = [waterObject,teaObject,oilObject,riceObject,soySauceObject,onionObject]

let combos: [Set<String>: String] = [
    ["Tea","Soy Sauce"]: "Tea Eggs",
    ["Onions","Water"]: "Red Eggs",
    ["Soy Sauce","Water"]: "Half-Boiled Eggs",
    ["Rice","Oil"]: "Egg Fried Rice",
    ["Rice","Water"]: "Century Egg Porridge",
    ["Onions","Oil"]: "Onion Omelette"
]

var selectionList = SelectionList()

let textWidth: CGFloat = 200

var recipeImageName: String = "empty"

var recipeFound: Bool = false

var audioPlayer = AudioPlayer()

extension CGPoint {
    static func - (lhs: CGPoint, rhs: CGPoint) -> CGPoint {
        return CGPoint(x: lhs.x - rhs.x, y: lhs.y - rhs.y)
    }
}

