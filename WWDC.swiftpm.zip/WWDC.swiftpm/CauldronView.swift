//
//  CauldronView.swift
//  WWDC
//
//  Created by Leo Harnadi on 15/04/23.
//

import SwiftUI

struct CauldronView: View {
    @ObservedObject var cauldron: ButtonObject = cauldronObject
    
    var body: some View {
        Image(cauldron.imageName)
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(height: frameHeight * 0.5)
            .scaleEffect(1.35)
            .offset(y:frameHeight*0.15)
            .background(
                    GeometryReader { geometry in
                        Color.clear
                            .onAppear {
                                cauldron.objectPosition = CGPoint(x: geometry.frame(in: .global).midX, y: geometry.frame(in: .global).midY)
                            }
                    }
            )
//            .rotationEffect(.degrees(2.5))
            .rotationEffect(.degrees(Double(cauldron.isShaking)))
            
    }
}

