//
//  RecipeData.swift
//  WWDC
//
//  Created by Leo Harnadi on 15/04/23.
//

import Foundation
import SwiftUI

struct RecipeData: Hashable {
    let imageName: String
    let chineseName: String
    let chinesePronounciation: String
    let ingredients: String
    let instructions: String
    let story: String
}

let recipeData = [
        RecipeData(imageName: "Tea Eggs",
                   chineseName: "茶叶蛋",
                   chinesePronounciation: "/ Chá Yè Dàn /",
                   ingredients: "• Egg\n• Tea Leaves\n• Soy Sauce\n• Water",
                   instructions: "1. Put eggs in boiling water for 7 minutes\n2. Let the eggs cool down then lightly crack the eggs\n3. Create a sauce base by mixing and boiling tea leaves with soy sauce\n4. Soak the eggs into the sauce for 24 hours",
                   story: "Growing up, tea eggs are one of my favorite snacks. Every friday, my grandma reward my sister and I for finishing a week of school. It was a tradition that we always looked forward to. When the smell of the eggs fills the house, my sister and I would race to see who would be able to eat them first.\n\nI still remember biting into the perfectly marbled egg, with its unique pattern created as the sauce seeped into the egg for a whole day.\n\nTo this day, I still try to reach that level of mastery for such a relatively simple dish. Let us strive to achieve a perfect balance of flavor and texture that made my weekends so special."),
        RecipeData(imageName: "Century Egg Porridge",
                   chineseName: "皮蛋粥",
                   chinesePronounciation: "/ Pí Dàn Zhōu /",
                   ingredients: "• Century Egg\n• Rice\n• Water\n• Chicken Stock\n• Green Onion",
                   instructions: "1. Combine Rice, Water and Stock in the pot and simmer for 25 minutes\n2. (Optional) To get a thicker porridge, simmer for another 20-25 minutes while stirring\n3. Add the century egg and thinly sliced green onions into the porridge.\n4. Stir well and serve",
                   story: "Century Egg Porridge is one of my family's oldest recipes. It is said that my great-grandfather, who lived in rural China, did not have much to live by. To survive, he learned to preserve eggs using quicklime, clay, ash and salt. This process is what made century eggs their unique taste and texture. Eventually, he found that these eggs are perfect when paired with porridge, and so was born the tradition of cooking Century Egg Porridge in my family\n\nAs the current youngest generation within my family, I have inherited the recipe for this dish. Although I now prefer to  buy the eggs at the store, this dish still connects me to the memories of my family's hardwork and resilience. Everytime I cook this dish, I feel a deep sense of pride for my heritage, and I hope you can feel the same too."),
        RecipeData(imageName: "Red Eggs",
                   chineseName: "红鸡蛋",
                   chinesePronounciation: "/ Hóng Jī Dàn /",
                   ingredients: "• Egg\n• Yellow Onion\n• Water\n• White Vinegar",
                   instructions: "1. Boil the eggs in water, it can either be hard or soft boiled\n2. Peel the skins from the yellow onions\n3. Boil a mixture of onion skins, water and vinegar for 30 minutes\n4. Soak the eggs for 1-24 hours depending on the desired color",
                   story: "Red eggs are a symbol of happiness and celebration in my family, as it is usually served during birthdays. In chinese culture, the red color is believed to ward evil spirits off and brings good fortune.\n\nAlthough red eggs are widely prepared by using food coloring, I feel proud of my family to still be using the traditional method of onions. It is always a fun surprise when people discovered that the *red* eggs are created from boiled *yellow* onion skins.\n\nAlthough these red eggs are simple in terms of flavor and preparation, they still play a significant cultural and emotional role in my family's celebrations"),
        RecipeData(imageName: "Half-Boiled Eggs",
                   chineseName: "软煮蛋",
                   chinesePronounciation: "/ Ruǎn Zhǔ Dàn /",
                   ingredients: "• Egg\n• Soy Sauce\n• Water\n• Pepper",
                   instructions: "1. Bring water to boil in a pot\n2. Place the egg in the pot for 6 minutes\n3. Crack and pour the egg into a plate\n4. Serve with soy sauce and pepper",
                   story: "Half-boiled Eggs is very special to me as it is the first thing I've ever learned to cook. When I first ate this dish, I was almost instantly addicted and wanted to learn cooking just from that. This dish is very prevalent in the area of my hometown, Batam, and is rarely known by other people. It is always a fun time to introduce this simple and delicious dish to others. This dish goes well with Kaya Toast and a cup of coffee, which is a common set for breakfast in Singapore, which sits right next to Batam.\n\n These eggs are unique as it reminds me of home, and that no matter how far I'll travel, I'll always be connected to home."),
        RecipeData(imageName: "Egg Fried Rice",
                   chineseName: "蛋炒饭",
                   chinesePronounciation: "/ Dàn Chǎo Fàn /",
                   ingredients: "• Egg\n• Rice\n• Oil\n• Garlic",
                   instructions: "1. Beat the eggs until the yolk and white are mixed and cook over oil in a wok\n2. Add minced garlic and rice into the wok\n3. Stir and mix the mixture well. Flip and toss to cook the rice evenly\n4. (Optional) Pour soy sauce, salt, and sesame oil for more flavours",
                   story: "For as long as I can remember, Egg Fried Rice has been a staple dish in my family, cooked by my grandparents, parents, and even cousins. This dish is commonly served when there wasn't much time to prepare for a meal.\n\nI've always loved the sound of a sizzling wok as I anticipated the flavours while the aroma fills the room. As I've grown up , I've learned to create egg fried rice by myself, and what still surprises me is that my mouth still waters as the wok shizzles to this day. This dish connects me to my family members and reminds me that even if we are apart, we are still cooking the same ol' dish."),
        RecipeData(imageName: "Onion Omelette",
                   chineseName: "洋葱煎蛋",
                   chinesePronounciation: "/ Yáng Cōng Jiān Dàn /",
                   ingredients: "• Egg\n• Spring Onion\n• Oil",
                   instructions: "1. Lightly beat eggs until the yold and whites are mixed\n2. Heal oil in the wok and fry the eggs with the cut spring onions.\n3. Stir well until cooked",
                   story: "Onion Omelettes are one of my favorite egg dishes. Back in the day, whenever I am hungry or is craving a snack, my late grandfather would whip it up in an instant, and my hunger would quell as a result. \n\nWhenever he cooked this, we would make small talks and just have a good time being in each other's side, this is still one of my fondest memories to look back to. Now that I'm older, I've always tried to socialize whenever I cook with people to live up to my grandfather's memories. This dish transports me back to those days with him, and is a representation of the importance of spending time with our loved ones")
    ]
