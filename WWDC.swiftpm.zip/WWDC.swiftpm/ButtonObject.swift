//
//  ButtonObject.swift
//  WWDC
//
//  Created by Leo Harnadi on 10/04/23.
//

import Foundation
import SwiftUI

class ButtonObject: ObservableObject, Identifiable {
    var id = UUID()
    var imageName: String
    @Published var isSelected: Bool
    @Published var isShaking: Double
    @Published var objectPosition: CGPoint
    @Published var objectTarget: CGPoint
    @Published var shakeValue: CGFloat
//    {
//        didSet {
//            if isShaking >= 2 {
//                isShaking = 0
//            }
//            }
//    }
    
    
    init(imageName: String = "testImg") {
        self.imageName = imageName
        self.isSelected = false
        self.isShaking = 0
        self.objectPosition = .zero
        self.objectTarget = .zero
        self.shakeValue = 0
    }
}
