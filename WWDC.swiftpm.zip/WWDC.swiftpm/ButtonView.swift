//
//  ObjectView.swift
//  WWDC
//
//  Created by Leo Harnadi on 10/04/23.
//

import SwiftUI

struct ButtonView: View {
    @ObservedObject var buttonObject: ButtonObject
    
    
    
    var body: some View {
            
        Button {
            if !recipeFound {
                withAnimation(.easeInOut(duration: 0.4)) {
                    if !(selectionList.selection.count >= 2 && !buttonObject.isSelected) {
                        buttonObject.isSelected.toggle()
                        audioPlayer.click()
                    }
                    
                }
                if (!selectionList.selection.contains(where: { $0.imageName == buttonObject.imageName }) && selectionList.selection.count < 2){
                    selectionList.addItem(buttonObject)
                } else if selectionList.selection.contains(where: {$0.imageName == buttonObject.imageName} ) {
                    selectionList.selection.removeAll(where: {$0.imageName == buttonObject.imageName} )
                }
            }
            
        } label: {
            Image(buttonObject.imageName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(height: frameHeight * 0.08)
        }
        .shadow(radius: buttonObject.isSelected ? 5 : 10)
        .scaleEffect(buttonObject.isSelected ? 1.2 : 1)
        .opacity(buttonObject.isSelected ? 1 : 0.9)
        .background(
                GeometryReader { geometry in
                    Color.clear
                        .onAppear {
                            buttonObject.objectPosition = CGPoint(x: geometry.frame(in: .global).midX, y: geometry.frame(in: .global).midY)
                        }
                }
        )
        .offset(x: buttonObject.shakeValue)
        .offset(x: buttonObject.objectTarget.x, y: buttonObject.objectTarget.y)
        
        
    }
}
